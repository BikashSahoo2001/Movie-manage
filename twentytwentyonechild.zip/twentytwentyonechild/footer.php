<footer>
    <div class="container">
      <div class="col-lg-12">
        <p>Copyright © 2048 FREE MOVIES. All rights reserved. &nbsp;&nbsp;</p>
      </div>
    </div>
  </footer>
    <?php wp_footer(); ?>
  </body>
</html>






